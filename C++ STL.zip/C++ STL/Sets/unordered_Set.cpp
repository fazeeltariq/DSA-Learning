#include<bits/stdc++.h>
using namespace std;
int main()
{
    // Stores unique elements
    // Does not stores in sorted order

    unordered_set<string> s;
    s.insert("abc"); //O(1)
    s.insert("xyz");


    return 0;
}