#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;
    cin>>n;
    vector<pair<int,int>> v(n);
    for(int i=0;i<n;i++){
        // int x,y;
        // cin>>x>>y;
        // v.push_back({x,y});

        cin>>v[i].firs t> >v[i].second;
    }

   return 0;
}